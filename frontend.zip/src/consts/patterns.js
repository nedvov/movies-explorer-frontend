export const patterns = {
    namePattern: "^[а-яА-ЯёЁa-zA-Z0-9 -]+$",
}