export const apiURL = {
    mainApiUrl: "https://api.nedvov.movies.nomoredomains.club",
    moviesApiUrl: "https://api.nomoreparties.co",
}
